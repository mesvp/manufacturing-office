<?php

namespace App\Http\Controllers\ProductionLineUp\JunctionBox;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\ProductionLineUp\{JB_Model, JB_Damage_Model, JB_Hist_Model};

class JunctionBox_Controller extends Controller
{
    public  static function PermittedMenuList($sessionId){
      //Menu Permission
      $res = DB::table('prod_menu_laravel')
      ->leftJoin('prod_menu_acc_laravel', 'prod_menu_laravel.id', '=', 'prod_menu_acc_laravel.menu_id')
      ->where('prod_menu_acc_laravel.emp_id', '=', $sessionId)
      ->where('prod_menu_acc_laravel.accessType', '=', 'yes')
      ->select('prod_menu_laravel.*', 'prod_menu_acc_laravel.accessType')
      ->get();
      
      return $res;
    }
    public function getUserIP()
    {
        // Get real visitor IP behind CloudFlare network
        if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
            $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
            $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
        }
        $client = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote = $_SERVER['REMOTE_ADDR'];

        if (filter_var($client, FILTER_VALIDATE_IP)) {
            $ip = $client;
        } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }

        return $ip;
    }
    public function index()
    {
        $data['menu'] = 'junctionbox';

        $Condition = 'jb.jb_QC IS NULL AND ninetydeg.status = 1';
        $Cond = [];

        if (isset($_GET['createdBy']) && $_GET['createdBy'] != '') {
            $Cond[] = "ninetydeg.created_by = '" . $_GET['createdBy'] . "'";
        }
        if (isset($_GET['operator']) && $_GET['operator'] != '') {
            $Cond[] = "ninetydeg.ninetydeg_operator = '" . $_GET['operator'] . "'";
        }
        if (isset($_GET['checker']) && $_GET['checker'] != '') {
            $Cond[] = "ninetydeg.ninetydeg_incharge = '" . $_GET['checker'] . "'";
        }
        if (isset($_GET['shift']) && $_GET['shift'] != '') {
            $Cond[] = "ninetydeg.ninetydeg_shift = '" . $_GET['shift'] . "'";
        }
        if (isset($_GET['fromDate']) && $_GET['fromDate'] != '') {
            $Cond[] = "CAST(ninetydeg.created_at AS DATE) >= '" . $_GET['fromDate'] . "'";
        }
        if (isset($_GET['toDate']) && $_GET['toDate'] != '') {
            $Cond[] = "CAST(ninetydeg.created_at AS DATE) <= '" . $_GET['toDate'] . "'";
        }
        if (isset($_GET['batchNo']) && $_GET['batchNo'] != '') {
            $Cond[] = "ninetydeg.ninetydeg_batchNo = '" . $_GET['batchNo'] . "'";
        }
        if (count($Cond) > 0) {
            $Condition = $Condition . ' AND ' . implode(' AND ', $Cond);
        }

        $sql = "SELECT 
            ninetydeg.*,
            psl.wattage,
            psml.size AS cellSize,
            sh.shift AS shiftdtl,
            a.fullname AS ninetydeg_operator,
            b.fullname AS ninetydeg_incharge,
            c.fullname AS createdBy
            FROM tbl_factory_ninetydeg_laravel AS ninetydeg
            LEFT JOIN tbl_factory_jb_laravel AS jb
                ON jb.jb_QC = ninetydeg.ninetydeg_id
            LEFT JOIN hr_mstr_shift AS sh
                ON sh.id = ninetydeg.ninetydeg_shift
            LEFT JOIN tbl_factory_production_setup_laravel AS psl 
                ON psl.batchNo = ninetydeg.ninetydeg_batchNo
            LEFT JOIN tbl_factory_production_setup_material_laravel AS psml 
                ON psml.batchNo = psl.batchNo
            LEFT JOIN mstr_emp AS a 
                ON ninetydeg.ninetydeg_operator = a.id
            LEFT JOIN mstr_emp AS b
                ON ninetydeg.ninetydeg_incharge = b.id
            LEFT JOIN mstr_emp AS c
                ON ninetydeg.created_by = c.id
            WHERE $Condition
            GROUP BY ninetydeg.ninetydeg_barcode 
            ORDER BY ninetydeg.created_at DESC";
        // dd($sql);
        $data['AllLists'] = DB::select($sql);

        $sql = "SELECT 
        jb.*,
        psl.wattage,
        sh.shift AS shiftdtl,
        a.fullname AS jb_operator,
        b.fullname AS jb_incharge,
        c.fullname AS createdBy
        FROM tbl_factory_jb_laravel AS jb
        LEFT JOIN hr_mstr_shift AS sh 
            ON sh.id = jb.jb_shift
        LEFT JOIN tbl_factory_production_setup_laravel AS psl 
            ON psl.batchNo = jb.jb_batchNo
        LEFT JOIN mstr_emp AS a 
            ON jb.jb_operator = a.id 
        LEFT JOIN mstr_emp AS b 
            ON jb.jb_incharge = b.id
        LEFT JOIN mstr_emp AS c 
            ON jb.created_by = c.id
        GROUP BY jb.jb_id
        ORDER BY jb.created_at DESC";
        // dd($sql);
        $data['AllLaminatorLists'] = DB::select($sql);

        $data['PermittedMenuList'] = self::PermittedMenuList(request()->session()->get('empId'));
        return view('ProductionLineUp.junctionbox.index', $data);
    }



    public function indexAll()
    {
        $data['menu'] = 'junctionbox-all';

        $Condition = 'jb.jb_QC IS NULL AND ninetydeg.status = 1';
        $Cond = [];

        if (isset($_GET['createdBy']) && $_GET['createdBy'] != '') {
            $Cond[] = "ninetydeg.created_by = '" . $_GET['createdBy'] . "'";
        }
        if (isset($_GET['operator']) && $_GET['operator'] != '') {
            $Cond[] = "ninetydeg.ninetydeg_operator = '" . $_GET['operator'] . "'";
        }
        if (isset($_GET['checker']) && $_GET['checker'] != '') {
            $Cond[] = "ninetydeg.ninetydeg_incharge = '" . $_GET['checker'] . "'";
        }
        if (isset($_GET['shift']) && $_GET['shift'] != '') {
            $Cond[] = "ninetydeg.ninetydeg_shift = '" . $_GET['shift'] . "'";
        }
        if (isset($_GET['fromDate']) && $_GET['fromDate'] != '') {
            $Cond[] = "CAST(ninetydeg.created_at AS DATE) >= '" . $_GET['fromDate'] . "'";
        }
        if (isset($_GET['toDate']) && $_GET['toDate'] != '') {
            $Cond[] = "CAST(ninetydeg.created_at AS DATE) <= '" . $_GET['toDate'] . "'";
        }
        if (isset($_GET['batchNo']) && $_GET['batchNo'] != '') {
            $Cond[] = "ninetydeg.ninetydeg_batchNo = '" . $_GET['batchNo'] . "'";
        }
        if (count($Cond) > 0) {
            $Condition = $Condition . ' AND ' . implode(' AND ', $Cond);
        }

        $sql = "SELECT 
            ninetydeg.*,
            psl.wattage,
            psml.size AS cellSize,
            sh.shift AS shiftdtl,
            a.fullname AS ninetydeg_operator,
            b.fullname AS ninetydeg_incharge,
            c.fullname AS createdBy
            FROM tbl_factory_ninetydeg_laravel AS ninetydeg
            LEFT JOIN tbl_factory_jb_laravel AS jb
                ON jb.jb_QC = ninetydeg.ninetydeg_id
            LEFT JOIN hr_mstr_shift AS sh
                ON sh.id = ninetydeg.ninetydeg_shift
            LEFT JOIN tbl_factory_production_setup_laravel AS psl 
                ON psl.batchNo = ninetydeg.ninetydeg_batchNo
            LEFT JOIN tbl_factory_production_setup_material_laravel AS psml 
                ON psml.batchNo = psl.batchNo
            LEFT JOIN mstr_emp AS a 
                ON ninetydeg.ninetydeg_operator = a.id
            LEFT JOIN mstr_emp AS b
                ON ninetydeg.ninetydeg_incharge = b.id
            LEFT JOIN mstr_emp AS c
                ON ninetydeg.created_by = c.id
            WHERE $Condition
            GROUP BY ninetydeg.ninetydeg_barcode 
            ORDER BY ninetydeg.created_at DESC";
        // dd($sql);
        $data['AllLists'] = DB::select($sql);

        $sql = "SELECT 
        jb.*,
        psl.wattage,
        sh.shift AS shiftdtl,
        a.fullname AS jb_operator,
        b.fullname AS jb_incharge,
        c.fullname AS createdBy
        FROM tbl_factory_jb_laravel AS jb
        LEFT JOIN hr_mstr_shift AS sh 
            ON sh.id = jb.jb_shift
        LEFT JOIN tbl_factory_production_setup_laravel AS psl 
            ON psl.batchNo = jb.jb_batchNo
        LEFT JOIN mstr_emp AS a 
            ON jb.jb_operator = a.id 
        LEFT JOIN mstr_emp AS b 
            ON jb.jb_incharge = b.id
        LEFT JOIN mstr_emp AS c 
            ON jb.created_by = c.id
        GROUP BY jb.jb_id
        ORDER BY jb.created_at DESC";
        // dd($sql);
        $data['AllLaminatorLists'] = DB::select($sql);

        $data['PermittedMenuList'] = self::PermittedMenuList(request()->session()->get('empId'));
        return view('ProductionLineUp.junctionbox.all-list', $data);
    }
    
    
    
    public function addJunctionBox()
    {
        $data['menu'] = 'junctionbox';
        $data['ShiftMaster'] = DB::table('hr_mstr_shift')
            ->select('hr_mstr_shift.*')
            ->get();
        $data['PlantMaster'] = DB::table('master_type_dtls')
            ->select('master_type_dtls.*')
            ->where('master_type_dtls.parent_id', 42)
            ->get();
        $data['materialMaster'] = DB::table('tbl_factory_material_master_laravel')
            ->select('id', 'title')
            ->get();
        $data['DmgRsn'] = DB::table('master_type_dtls')
            ->select('master_type_dtls.*')
            ->where('master_type_dtls.parent_id', 44)
            ->get();
        $data['DmgCat'] = DB::table('master_type_dtls')
            ->select('master_type_dtls.*')
            ->where('master_type_dtls.parent_id', 43)
            ->get();
        $data['DmgMachine'] = DB::table('master_type_dtls')
            ->select('master_type_dtls.*')
            ->where('master_type_dtls.parent_id', 88)
            ->get();
        $data['userList'] = DB::table('mstr_emp')
            ->select('mstr_emp.id', 'mstr_emp.fullname')
            ->get();
        $data['bushingNo'] = DB::table('tbl_factory_bushing_laravel as a')
            ->select('a.bushing_batchNo')
            ->distinct()
            ->get();

        // $batchNo = request()->get('id');
        // $data['bushingMaterial'] = DB::table('tbl_factory_production_setup_laravel as psl')
        //     ->select('psl.cellRow', 'psl.celColumn')
        //     ->where('psl.batchNo', $batchNo)
        //     ->first();


        if(isset($_GET['id'])){
          $getBatchNo = $_GET['id'];
          $getBarcode = request()->get('bid');

          $data['bushingMaterial'] = DB::table('tbl_factory_production_setup_laravel as psl')
            ->join('tbl_factory_production_setup_material_laravel as psml', 'psml.batchNo', '=', 'psl.batchNo')
            ->join('tbl_factory_material_master_laravel as m', 'm.id', '=', 'psml.material')
            ->select('m.title as matname', 'm.id as matid', 'psl.wattage', 'psml.size AS msize', 'psml.brand AS mbrand')
            ->where('psl.batchNo', $getBatchNo)
            ->get();

          $data['bushingLogo'] = DB::table('tbl_factory_bushing_laravel')
            ->select('bushing_logo')
            ->where('bushing_barCode', $getBarcode)
            ->first();

          
        }

        $data['PermittedMenuList'] = self::PermittedMenuList(request()->session()->get('empId'));
        return view('ProductionLineUp.junctionbox.add', $data);
    }


    public function getBushingMaterial(Request $request)
    {
        $batchno = $request->input('q');
        // $batchno = DB::table('tbl_factory_bushing_laravel')
        //     ->where('bushing_id', $bushingno)
        //     ->value('bushing_batchNo');
        $bushingMaterial = DB::table('tbl_factory_production_setup_laravel as psl')
            ->join('tbl_factory_production_setup_material_laravel as psml', 'psml.batchNo', '=', 'psl.batchNo')
            ->join('tbl_factory_material_master_laravel as m', 'm.id', '=', 'psml.material')
            ->select('m.title as matname', 'm.id as matid', 'psl.wattage', 'psml.size AS msize', 'psml.brand AS mbrand')
            ->where('psl.batchNo', $batchno)
            ->get();

        foreach ($bushingMaterial as $item)
            return response()->json([
                'batchno' => $batchno,
                'materials' => $bushingMaterial,
                'wattage' => $item->wattage ?? 'N/A',
                'size' => $item->msize ?? 'N/A',
                'brand' => $item->mbrand ?? 'N/A',
            ]);
    }

    public function validateBarCode(Request $request)
    {
        $barcode = $request->get('barCode');
        $btch_viewNo = $request->get('id');
        $action = $request->get('action') ?? '';
        $batchNo = $request->get('id') ?? '';
        
        if ($action === 'view') {
            $exists = DB::table('tbl_factory_bushing_laravel')
            ->select('bushing_logo')
            ->where('bushing_barCode', $barcode)
            ->where('bushing_batchNo', $btch_viewNo)
            //->where('bushing_id', $btch_viewNo)
            ->first();
        } else {
            $exists = DB::table('tbl_factory_bushing_laravel')
            ->select('bushing_id' , 'bushing_logo')
            ->where('bushing_barCode', $barcode)
            ->where('bushing_batchNo', $batchNo)
            ->get();
        }
            
        // If action is 'view', we're in view mode - skip EL QC validation
        if ($action === 'view') {
            return response()->json([
                'status' => 'success',
                'bushing_logo' => $exists->bushing_logo ?? null,
                'message' => 'Barcode is valid (view mode).',
            ]);
        }
            
        // Check if barcode passed in 90Deg QC or Not
        $passExists = DB::table('tbl_factory_ninetydeg_laravel')
            ->where('ninetydeg_barcode', $barcode)
            ->where('ninetydeg_batchNo', $batchNo)
            ->exists(); 
            
        // Check if barcode already used in JB
        $elQcExists = DB::table('tbl_factory_jb_laravel')
            ->where('jb_barcode', $barcode)
            ->where('jb_batchNo', $batchNo)
            ->exists();
    
        // If found in EL QC - INVALID
        if ($elQcExists) {
            return response()->json([
                'status' => 'error',
                'message' => 'Barcode already used in Junction Box.',
            ]);
        }
        if (!$passExists) {
            return response()->json([
                'status' => 'error',
                'message' => 'Barcode is not passed 90 degree QC against this batchno.',
            ]);
        }
        if ($exists->isEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Barcode is not valid against this batchno.',
            ]);
        } else {
            return response()->json([
                'status' => 'success',
                'bushing_id' => $exists[0]->bushing_id ?? null,
                'bushing_logo' => $exists[0]->bushing_logo,
                'message' => 'Barcode is valid.',
            ]);
        }

        return response()->json(['exists' => $exists]);
    }


    public function insert(Request $request){


      if ($request->input('err') == '1') {
            return redirect()->back()->with('error', 'Please correct the errors before submitting the form.');
        } else {
            
            $Bexists = DB::table('tbl_factory_bushing_laravel')
            ->where('bushing_barCode', $request->input('barCode'))
            ->where('bushing_batchNo', $request->input('batchNo'))
            ->exists();
            $PreExists = DB::table('tbl_factory_ninetydeg_laravel')
            ->where('ninetydeg_barcode',  $request->input('barCode'))
            ->where('ninetydeg_batchNo', $request->input('batchNo'))
            ->exists(); 
            
            if($Bexists == true && $PreExists == true){
            
                $exists = DB::table('tbl_factory_jb_laravel')
                  ->where('jb_barcode', $request->input('barCode'))
                  ->exists();
                  
                if($exists == false){
                    
                    $qcId = DB::table('tbl_factory_ninetydeg_laravel')
                  ->where('ninetydeg_barcode', $request->input('barCode'))
                  ->where('ninetydeg_batchNo', $request->input('batchNo'))
                  ->value('ninetydeg_id');
        
                    $id = date('YmdHis');
                    $data = array(
                        'jb_id' => $id,
                        'jb_date' => date('d-m-Y'),
                        'jb_time' => date('H:i:s'),
                        'jb_operator' => $request->input('operator'),
                        'jb_source' => '90 deg QC',
                        'jb_QC' => $qcId,
                        'jb_batchNo' => $request->input('batchNo'),
                        'jb_incharge' => $request->input('incharge'),
                        'jb_cycle_no' => $request->input('cycleNo'),
                        'jb_shift' => $request->input('shift'),
                        'jb_plant' => $request->input('plant'),
                        'status' => $request->input('el_type'),
                        'jb_pDefectRsn' => $request->input('p_reject_reason'),
                        'jb_rfid' => $request->input('rfid'),
                        'jb_barcode' => $request->input('barCode'),
                        'created_by' => $request->session()->get('empId')
                    );
        
        
                    $res = JB_Model::create($data);
                    
                    JB_Hist_Model::create([
                        'jb_id' => $id,
                        'action' => 'Raised',
                        'ip_address' => $this->getUserIP(),
                        'created_by' => auth()->id()
                    ]);
                    $type = $request->input('type', []);
                    $size = $request->input('size', []);
                    $brand = $request->input('brand', []);
                    $qty = $request->input('qty', []);
                    $uom = $request->input('uom', []);
        
                    if ($request->input('el_type') === '0' && is_array($type) && count($type) > 0) {
                        foreach ($type as $i => $dfctType) {
                            // skip empty rows (optional)
                            if ($dfctType === null || $dfctType === '') {
                                continue;
                            }
        
                            $defectData = array(
                                'jb_Id' => $id,
                                'type' => $dfctType,
                                'size' => $size[$i] ?? null,
                                'brand' => $brand[$i] ?? null,
                                'qty' => $qty[$i] ?? null,
                                'uom' => $uom[$i] ?? null,
                            );
        
                            JB_Damage_Model::create($defectData);
                        }
                    }
                    $lock = request()->input('lock');
                    $batchNo = request()->input('batchNo');
                    $oprtr = request()->input('operator');
                    $incherge = request()->input('incharge');
                    $shift = request()->input('shift');
                    $plant = request()->input('plant');
                    $page = request()->input('page');
                    if ($res->exists) {
                        if ($lock && $page) {
                            $url = 'production-lineup/junctionbox/add?page=ALL&lock=1&batchNo=' . $batchNo . '&operator=' . $oprtr . '&shift=' . $shift . '&incharge=' . $incherge . '&plant=' . $plant;
                            return redirect($url)->with('success', ' Junction Box data stored successfully!');
                        } else {
                           //$url = ;
                            return redirect('production-lineup/junctionbox')->with('success', ' Junction Box data stored successfully!');
                        }
                    }
                }else {
                   //$url = ;
                  return redirect('production-lineup/junctionbox')->with('success', ' Junction Box data stored faild! Duplicate Barcode');
                }
            }else {
                   //$url = ;
              return redirect('production-lineup/junctionbox')->with('success', ' Junction Box data stored faild! Barcode Not Passed in Either Layout Setup or Ninety Degree QC');
            }
        }
    }


    public function view_jb($id = null){
      
        //echo 'hi'; exit;
      $data['menu'] = 'junctionbox';
      $data['laminatorDetails'] = DB::table('tbl_factory_jb_laravel as jb')
          ->leftJoin('mstr_emp as emp1', 'jb.jb_operator', '=', 'emp1.id')
          ->leftJoin('mstr_emp as emp2', 'jb.jb_incharge', '=', 'emp2.id')
          ->leftJoin('hr_mstr_shift as sh', 'jb.jb_shift', '=', 'sh.id')
          ->select('jb.*', 'emp1.fullname as operator_name', 'emp2.fullname as incharge_name', 'sh.shift as shift_name')
          ->where('jb.jb_id', $id)
          ->first();
      $data['defectDetails'] = DB::table('tbl_factory_jb_defect_laravel as def')
          ->select('def.*')
          ->where('def.jb_Id', $id)
          ->get();
      $data['laminatorHistory'] = DB::table('tbl_factory_jb_history_laravel as history')
          ->select('history.*', 'emp.fullname as created_by')
          ->leftJoin('mstr_emp as emp', 'history.created_by', '=', 'emp.id')
          ->where('history.jb_id', $id)
          ->get();
      $data['DmgRsn'] = DB::table('master_type_dtls')
          ->select('master_type_dtls.*')
          ->where('master_type_dtls.parent_id', 44)
          ->get();
      $data['DmgCat'] = DB::table('master_type_dtls')
          ->select('master_type_dtls.*')
          ->where('master_type_dtls.parent_id', 43)
          ->get();
      $data['DmgMachine'] = DB::table('master_type_dtls')
          ->select('master_type_dtls.*')
          ->where('master_type_dtls.parent_id', 47)
          ->get();
      $data['userList'] = DB::table('mstr_emp')
          ->select('mstr_emp.id', 'mstr_emp.fullname')
          ->where('mstr_emp.status', '1')
          ->get();
      $batchNo = $data['laminatorDetails']->jb_batchNo;
      $data['bushingMaterial'] = DB::table('tbl_factory_production_setup_laravel as psl')
          ->select('psl.cellRow', 'psl.celColumn')
          ->where('psl.batchNo', $batchNo)
          ->first();
          
        $data['PermittedMenuList'] = self::PermittedMenuList(request()->session()->get('empId'));
        return view('ProductionLineUp.junctionbox.view_jb', $data);
    
    }


}
