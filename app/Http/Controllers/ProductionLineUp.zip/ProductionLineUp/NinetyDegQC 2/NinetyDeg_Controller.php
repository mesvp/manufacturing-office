<?php

namespace App\Http\Controllers\ProductionLineUp\NinetyDegQC;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\ProductionLineUp\{NinetyDeg_Model, NinetyDegDamage_Model, NinetyDegHist_Model};

class NinetyDeg_Controller extends Controller
{
    public  static function PermittedMenuList($sessionId){
      //Menu Permission
      $res = DB::table('prod_menu_laravel')
      ->leftJoin('prod_menu_acc_laravel', 'prod_menu_laravel.id', '=', 'prod_menu_acc_laravel.menu_id')
      ->where('prod_menu_acc_laravel.emp_id', '=', $sessionId)
      ->where('prod_menu_acc_laravel.accessType', '=', 'yes')
      ->select('prod_menu_laravel.*', 'prod_menu_acc_laravel.accessType')
      ->get();
      
      return $res;
    }
    //
    public function getUserIP()
    {
        // Get real visitor IP behind CloudFlare network
        if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
            $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
            $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
        }
        $client = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote = $_SERVER['REMOTE_ADDR'];

        if (filter_var($client, FILTER_VALIDATE_IP)) {
            $ip = $client;
        } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }

        return $ip;
    }
    
    public function index()
    {
        $data['menu'] = '90deg-qc';
        
        $Condition = "((ninetydeg.ninetydeg_laminatorNo IS NULL AND elqc.status = 1) 
               OR 
              (ninetydeg.rwrk_status = '' AND ninetydeg.status = 0))";

        $Cond = [];

        if (isset($_GET['createdBy']) && $_GET['createdBy'] != '') {
            $Cond[] = "elqc.created_by = '" . $_GET['createdBy'] . "'";
        }
        if (isset($_GET['operator']) && $_GET['operator'] != '') {
            $Cond[] = "elqc.elqc_operator = '" . $_GET['operator'] . "'";
        }
        if (isset($_GET['checker']) && $_GET['checker'] != '') {
            $Cond[] = "elqc.elqc_incharge = '" . $_GET['checker'] . "'";
        }
        if (isset($_GET['shift']) && $_GET['shift'] != '') {
            $Cond[] = "elqc.elqc_shift = '" . $_GET['shift'] . "'";
        }
        if (isset($_GET['fromDate']) && $_GET['fromDate'] != '') {
            $Cond[] = "CAST(elqc.created_at AS DATE) >= '" . $_GET['fromDate'] . "'";
        }
        if (isset($_GET['toDate']) && $_GET['toDate'] != '') {
            $Cond[] = "CAST(elqc.created_at AS DATE) <= '" . $_GET['toDate'] . "'";
        }
        if (isset($_GET['batchNo']) && $_GET['batchNo'] != '') {
            $Cond[] = "elqc.elqc_batchNo = '" . $_GET['batchNo'] . "'";
        }
        if (count($Cond) > 0) {
            $Condition = $Condition . ' AND ' . implode(' AND ', $Cond);
        }

        $sql = "SELECT 
            elqc.*,
            ninetydeg.ninetydeg_id,
            ninetydeg.status AS sts,
            ninetydeg.rwrk_status AS rwsts,
            ninetydeg.ninetydeg_source,
            psl.wattage,
            sh.shift AS shiftdtl,
            a.fullname AS elqc_operator,
            b.fullname AS elqc_incharge,
            c.fullname AS createdBy
            FROM tbl_factory_el_qc_laravel AS elqc
            LEFT JOIN tbl_factory_ninetydeg_laravel AS ninetydeg
                ON ninetydeg.ninetydeg_laminatorNo = elqc.elqc_id
            LEFT JOIN hr_mstr_shift AS sh
                ON sh.id = elqc.elqc_shift
            LEFT JOIN tbl_factory_production_setup_laravel AS psl 
                ON psl.batchNo = elqc.elqc_batchNo
            LEFT JOIN mstr_emp AS a 
                ON elqc.elqc_operator = a.id
            LEFT JOIN mstr_emp AS b
                ON elqc.elqc_incharge = b.id
            LEFT JOIN mstr_emp AS c
                ON elqc.created_by = c.id
            WHERE $Condition
            ORDER BY elqc.created_at DESC";
         //dd($sql);
        $data['AllLists'] = DB::select($sql);

        $sql = "SELECT 
        ninetydeg.*,
        psl.wattage,
        sh.shift AS shiftdtl,
        a.fullname AS ninetydeg_operator,
        b.fullname AS ninetydeg_incharge,
        c.fullname AS createdBy,
        (SELECT SUM(d2.cell_qty)
         FROM tbl_factory_ninetydeg_defect_laravel d2
         WHERE d2.ninetydeg_Id = ninetydeg.ninetydeg_id
        ) AS no_of_cell_damage
        FROM tbl_factory_ninetydeg_laravel AS ninetydeg
        LEFT JOIN hr_mstr_shift AS sh 
            ON sh.id = ninetydeg.ninetydeg_shift
        LEFT JOIN tbl_factory_production_setup_laravel AS psl 
            ON psl.batchNo = ninetydeg.ninetydeg_batchNo
        LEFT JOIN mstr_emp AS a 
            ON ninetydeg.ninetydeg_operator = a.id 
        LEFT JOIN mstr_emp AS b 
            ON ninetydeg.ninetydeg_incharge = b.id
        LEFT JOIN mstr_emp AS c 
            ON ninetydeg.created_by = c.id
        GROUP BY ninetydeg.ninetydeg_id
        ORDER BY ninetydeg.created_at DESC";
        // dd($sql);
        $data['AllLaminatorLists'] = DB::select($sql);
        $data['PermittedMenuList'] = self::PermittedMenuList(request()->session()->get('empId'));
        return view('ProductionLineUp.NinetyDeg.index', $data);
    }
    
    
    
    public function indexAll()
    {
        $data['menu'] = '90deg-qc-all';
        
        $Condition = "((ninetydeg.ninetydeg_laminatorNo IS NULL AND elqc.status = 1) 
               OR 
              (ninetydeg.rwrk_status = '' AND ninetydeg.status = 0))";

        $Cond = [];

        if (isset($_GET['createdBy']) && $_GET['createdBy'] != '') {
            $Cond[] = "elqc.created_by = '" . $_GET['createdBy'] . "'";
        }
        if (isset($_GET['operator']) && $_GET['operator'] != '') {
            $Cond[] = "elqc.elqc_operator = '" . $_GET['operator'] . "'";
        }
        if (isset($_GET['checker']) && $_GET['checker'] != '') {
            $Cond[] = "elqc.elqc_incharge = '" . $_GET['checker'] . "'";
        }
        if (isset($_GET['shift']) && $_GET['shift'] != '') {
            $Cond[] = "elqc.elqc_shift = '" . $_GET['shift'] . "'";
        }
        if (isset($_GET['fromDate']) && $_GET['fromDate'] != '') {
            $Cond[] = "CAST(elqc.created_at AS DATE) >= '" . $_GET['fromDate'] . "'";
        }
        if (isset($_GET['toDate']) && $_GET['toDate'] != '') {
            $Cond[] = "CAST(elqc.created_at AS DATE) <= '" . $_GET['toDate'] . "'";
        }
        if (isset($_GET['batchNo']) && $_GET['batchNo'] != '') {
            $Cond[] = "elqc.elqc_batchNo = '" . $_GET['batchNo'] . "'";
        }
        if (count($Cond) > 0) {
            $Condition = $Condition . ' AND ' . implode(' AND ', $Cond);
        }

        $sql = "SELECT 
            elqc.*,
            ninetydeg.ninetydeg_id,
            ninetydeg.status AS sts,
            ninetydeg.rwrk_status AS rwsts,
            ninetydeg.ninetydeg_source,
            psl.wattage,
            sh.shift AS shiftdtl,
            a.fullname AS elqc_operator,
            b.fullname AS elqc_incharge,
            c.fullname AS createdBy
            FROM tbl_factory_el_qc_laravel AS elqc
            LEFT JOIN tbl_factory_ninetydeg_laravel AS ninetydeg
                ON ninetydeg.ninetydeg_laminatorNo = elqc.elqc_id
            LEFT JOIN hr_mstr_shift AS sh
                ON sh.id = elqc.elqc_shift
            LEFT JOIN tbl_factory_production_setup_laravel AS psl 
                ON psl.batchNo = elqc.elqc_batchNo
            LEFT JOIN mstr_emp AS a 
                ON elqc.elqc_operator = a.id
            LEFT JOIN mstr_emp AS b
                ON elqc.elqc_incharge = b.id
            LEFT JOIN mstr_emp AS c
                ON elqc.created_by = c.id
            WHERE $Condition
            ORDER BY elqc.created_at DESC";
         //dd($sql);
        $data['AllLists'] = DB::select($sql);

        $sql = "SELECT 
        ninetydeg.*,
        psl.wattage,
        sh.shift AS shiftdtl,
        a.fullname AS ninetydeg_operator,
        b.fullname AS ninetydeg_incharge,
        c.fullname AS createdBy,
        (SELECT SUM(d2.cell_qty)
         FROM tbl_factory_ninetydeg_defect_laravel d2
         WHERE d2.ninetydeg_Id = ninetydeg.ninetydeg_id
        ) AS no_of_cell_damage
        FROM tbl_factory_ninetydeg_laravel AS ninetydeg
        LEFT JOIN hr_mstr_shift AS sh 
            ON sh.id = ninetydeg.ninetydeg_shift
        LEFT JOIN tbl_factory_production_setup_laravel AS psl 
            ON psl.batchNo = ninetydeg.ninetydeg_batchNo
        LEFT JOIN mstr_emp AS a 
            ON ninetydeg.ninetydeg_operator = a.id 
        LEFT JOIN mstr_emp AS b 
            ON ninetydeg.ninetydeg_incharge = b.id
        LEFT JOIN mstr_emp AS c 
            ON ninetydeg.created_by = c.id
        GROUP BY ninetydeg.ninetydeg_id
        ORDER BY ninetydeg.created_at DESC";
        // dd($sql);
        $data['AllLaminatorLists'] = DB::select($sql);
        $data['PermittedMenuList'] = self::PermittedMenuList(request()->session()->get('empId'));
        return view('ProductionLineUp.NinetyDeg.all-list', $data);
    }
    

    public function add_qc()
    {
        $data['menu'] = '90deg-qc';
        $data['ShiftMaster'] = DB::table('hr_mstr_shift')
            ->select('hr_mstr_shift.*')
            ->get();
        $data['PlantMaster'] = DB::table('master_type_dtls')
            ->select('master_type_dtls.*')
            ->where('master_type_dtls.parent_id', 42)
            ->get();
        $data['materialMaster'] = DB::table('tbl_factory_material_master_laravel')
            ->select('id', 'title')
            ->get();
        $data['DmgRsn'] = DB::table('master_type_dtls')
            ->select('master_type_dtls.*')
            ->where('master_type_dtls.parent_id', 44)
            ->get();
        $data['DmgCat'] = DB::table('master_type_dtls')
            ->select('master_type_dtls.*')
            ->where('master_type_dtls.parent_id', 43)
            ->get();
        $data['DmgMachine'] = DB::table('master_type_dtls')
            ->select('master_type_dtls.*')
            ->where('master_type_dtls.parent_id', 88)
            ->get();
        $data['userList'] = DB::table('mstr_emp')
            ->select('mstr_emp.id', 'mstr_emp.fullname')
            ->get();
        $data['bushingNo'] = DB::table('tbl_factory_bushing_laravel as a')
            ->select('a.bushing_batchNo')
            ->distinct()
            ->get();
        $batchNo = request()->get('id');
        $data['bushingMaterial'] = DB::table('tbl_factory_production_setup_laravel as psl')
            ->select('psl.cellRow', 'psl.celColumn')
            ->where('psl.batchNo', $batchNo)
            ->first();
        $data['PermittedMenuList'] = self::PermittedMenuList(request()->session()->get('empId'));
        return view('ProductionLineUp.NinetyDeg.add_qc', $data);
    }


    public function getLaminatorId(Request $request)
    {
        $batchNo = $request->q;

        $sql = "SELECT 
            elqc.elqc_id
            FROM tbl_factory_el_qc_laravel AS elqc
            LEFT JOIN tbl_factory_ninetydeg_laravel AS ninetydeg
                ON ninetydeg.ninetydeg_laminatorNo = elqc.elqc_id
            WHERE ninetydeg.ninetydeg_laminatorNo IS NULL AND elqc.elqc_batchNo = $batchNo
            ORDER BY elqc.created_at DESC";

        $elqcData = DB::select($sql);;

        if ($elqcData) {
            return response()->json(['elqc_ids' => $elqcData]);
        } else {
            return response()->json(['elqc_ids' => null]);
        }
    }


    public function getBushingMaterial(Request $request)
    {
        $batchno = $request->input('q');
        // $batchno = DB::table('tbl_factory_bushing_laravel')
        //     ->where('bushing_id', $bushingno)
        //     ->value('bushing_batchNo');
        $bushingMaterial = DB::table('tbl_factory_production_setup_laravel as psl')
            ->join('tbl_factory_production_setup_material_laravel as psml', 'psml.batchNo', '=', 'psl.batchNo')
            ->join('tbl_factory_material_master_laravel as m', 'm.id', '=', 'psml.material')
            ->select('m.title as matname', 'm.id as matid', 'psl.wattage', 'psml.size AS msize', 'psml.brand AS mbrand')
            ->where('psl.batchNo', $batchno)
            ->get();

        foreach ($bushingMaterial as $item)
            return response()->json([
                'batchno' => $batchno,
                'materials' => $bushingMaterial,
                'wattage' => $item->wattage ?? 'N/A',
                'size' => $item->msize ?? 'N/A',
                'brand' => $item->mbrand ?? 'N/A',
            ]);
    }

    public function validateBarCode(Request $request)
    {
        $barcode = $request->get('barCode');
        $btch_viewNo = $request->get('id');
        $action = $request->get('action') ?? '';
        $batchNo = $request->get('id') ?? '';
        
        if ($action === 'view') {
            $exists = DB::table('tbl_factory_bushing_laravel')
            ->select('bushing_logo')
            ->where('bushing_barCode', $barcode)
            ->where('bushing_batchNo', $btch_viewNo)
            //->where('bushing_id', $batchNo)
            ->first();
        } else {
            $exists = DB::table('tbl_factory_bushing_laravel')
            ->select('bushing_id' , 'bushing_logo')
            ->where('bushing_barCode', $barcode)
            ->where('bushing_batchNo', $batchNo)
            ->get();
        }
            
        // If action is 'view', we're in view mode - skip EL QC validation
        if ($action === 'view') {
            return response()->json([
                'status' => 'success',
                'bushing_logo' => $exists->bushing_logo ?? null,
                'message' => 'Barcode is valid (view mode).',
            ]);
        }
            
        // Check if barcode passed in 90Deg QC or Not
        $passExists = DB::table('tbl_factory_el_qc_laravel')
            ->where('elqc_barcode', $barcode)
            ->where('elqc_batchNo', $batchNo)
            ->exists(); 
            
        // Check if barcode already used in JB
        $elQcExists = DB::table('tbl_factory_ninetydeg_laravel')
            ->where('ninetydeg_barcode', $barcode)
            ->where('ninetydeg_batchNo', $batchNo)
            ->exists();
    
        // If found in EL QC - INVALID
        if ($elQcExists) {
            return response()->json([
                'status' => 'error',
                'message' => 'Barcode already used in Ninetydegree QC.',
            ]);
        }
        if (!$passExists) {
            return response()->json([
                'status' => 'error',
                'message' => 'Barcode is not passed ELQC against this batchno.',
            ]);
        }
        if ($exists->isEmpty()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Barcode is not valid against this batchno.',
            ]);
        } else {
            return response()->json([
                'status' => 'success',
                'bushing_id' => $exists[0]->bushing_id ?? null,
                'bushing_logo' => $exists[0]->bushing_logo,
                'message' => 'Barcode is valid.',
            ]);
        }

        return response()->json(['exists' => $exists]);
    }


    public function insert(Request $request){


      if ($request->input('err') == '1') {
            return redirect()->back()->with('error', 'Please correct the errors before submitting the form.');
        } else {
            
            $Bexists = DB::table('tbl_factory_bushing_laravel')
            ->where('bushing_barCode', $request->input('barCode'))
            ->where('bushing_batchNo', $request->input('batchNo'))
            ->exists();
            
            $PreExists = DB::table('tbl_factory_el_qc_laravel')
            ->where('elqc_barcode', $request->input('barCode'))
            ->where('elqc_batchNo', $request->input('batchNo'))
            ->exists(); 
            
            if($Bexists == true && $PreExists == true){
            
                $exists = DB::table('tbl_factory_ninetydeg_laravel')
                  ->where('ninetydeg_barcode', $request->input('barCode'))
                  ->exists();
                  
                if($exists == false){
                
                    $qcId = DB::table('tbl_factory_el_qc_laravel')
                    ->where('elqc_barcode', $request->input('barCode'))
                    ->where('elqc_batchNo', $request->input('batchNo'))
                  ->value('elqc_id');
                  
                    $id = date('YmdHis');
                    $data = array(
                        'ninetydeg_id' => $id,
                        'ninetydeg_date' => date('d-m-Y'),
                        'ninetydeg_time' => date('H:i:s'),
                        'ninetydeg_operator' => $request->input('operator'),
                        'ninetydeg_source' => 'ELQC',
                        'ninetydeg_laminatorNo' => $qcId,
                        'ninetydeg_batchNo' => $request->input('batchNo'),
                        'ninetydeg_incharge' => $request->input('incharge'),
                        'ninetydeg_cycle_no' => $request->input('cycleNo'),
                        'ninetydeg_shift' => $request->input('shift'),
                        'ninetydeg_plant' => $request->input('plant'),
                        'status' => $request->input('el_type'),
                        'rwrk_status' => '1',
                        'ninetydeg_pDefectRsn' => $request->input('p_reject_reason'),
                        'ninetydeg_rfid' => $request->input('rfid'),
                        'ninetydeg_barcode' => $request->input('barCode'),
                        'created_by' => $request->session()->get('empId')
                    );
                    
                    $res = NinetyDeg_Model::create($data);
                    
                    NinetyDegHist_Model::create([
                        'ninetydeg_id' => $id,
                        'action' => 'Raised',
                        'ip_address' => $this->getUserIP(),
                        'created_by' => auth()->id()
                    ]);
                    $cell_positions = $request->input('cell_position', []);
                    $cell_qtys = $request->input('cell_qty', []);
                    $dmgMat_reasons = $request->input('dmgMat_reason', []);
                    $defect_categories = $request->input('dmgMat_cat', []);
                    $res_prsns = $request->input('res_prsn', []);
                    $res_machines = $request->input('res_machine', []);
        
                    if ($request->input('el_type') === '0' && is_array($cell_positions) && count($cell_positions) > 0) {
                        foreach ($cell_positions as $i => $cell_no) {
                            // skip empty rows (optional)
                            if ($cell_no === null || $cell_no === '') {
                                continue;
                            }
        
                            $defectData = array(
                                'ninetydeg_Id' => $id,
                                'cell_no' => $cell_no,
                                'cell_qty' => $cell_qtys[$i] ?? null,
                                'defectRsn' => $dmgMat_reasons[$i] ?? null,
                                'defectCatgry' => $defect_categories[$i] ?? null,
                                'res_prsn' => $res_prsns[$i] ?? null,
                                'res_machine' => $res_machines[$i] ?? null,
                            );
        
                            NinetyDegDamage_Model::create($defectData);
                        }
                    }
                    $lock = request()->input('lock');
                    $batchNo = request()->input('batchNo');
                    $oprtr = request()->input('operator');
                    $incherge = request()->input('incharge');
                    $shift = request()->input('shift');
                    $plant = request()->input('plant');
                    $page = request()->input('page');
                    if ($res->exists) {
                        if ($lock && $page) {
                            $url = 'production-lineup/90deg-qc/add?page=ALL&lock=1&batchNo=' . $batchNo . '&operator=' . $oprtr . '&shift=' . $shift . '&incharge=' . $incherge . '&plant=' . $plant;
                            return redirect($url)->with('success', ' 90deg-qc data stored successfully!');
                        } else {
                            return redirect('production-lineup/90deg-qc')->with('success', '90deg-qc data stored successfully!');
                        }
                    }
                }else {
                    return redirect('production-lineup/90deg-qc')->with('success', '90deg-qc data stored failed! Duplicate Barcode');
                }
            }else {
                    return redirect('production-lineup/90deg-qc')->with('success', '90deg-qc data stored failed! Barcode Not Passed in Either Layout Setup or EL & QC');
                }
        }
    }
    
    public function damage_report()
    {
        $data['menu'] = '90deg-qc-damage-report';

        $sql = "SELECT 
        ninetydeg.*,
        psl.wattage,
        sh.shift AS shiftdtl,
        a.fullname AS ninetydeg_operator,
        b.fullname AS ninetydeg_incharge,
        c.fullname AS createdBy,
        (SELECT SUM(d2.cell_qty)
         FROM tbl_factory_ninetydeg_defect_laravel d2
         WHERE d2.ninetydeg_Id = ninetydeg.ninetydeg_id
        ) AS no_of_cell_damage
        FROM tbl_factory_ninetydeg_laravel AS ninetydeg
        LEFT JOIN hr_mstr_shift AS sh 
            ON sh.id = ninetydeg.ninetydeg_shift
        LEFT JOIN tbl_factory_production_setup_laravel AS psl 
            ON psl.batchNo = ninetydeg.ninetydeg_batchNo
        LEFT JOIN mstr_emp AS a 
            ON ninetydeg.ninetydeg_operator = a.id 
        LEFT JOIN mstr_emp AS b 
            ON ninetydeg.ninetydeg_incharge = b.id
        LEFT JOIN mstr_emp AS c 
            ON ninetydeg.created_by = c.id
        GROUP BY ninetydeg.ninetydeg_id
        ORDER BY ninetydeg.created_at DESC";

        // dd($sql);
        $data['AllDamageLists'] = DB::select($sql);
        //$data['menu'] = 'trimming-damage';
        $data['PermittedMenuList'] = self::PermittedMenuList(request()->session()->get('empId'));
        return view('ProductionLineUp.NinetyDeg.damage', $data);
    }
    
    
    public function view_90deg_qc($id = null)
    {
        //echo 'hi'; exit;
        $data['menu'] = '';
        $data['laminatorDetails'] = DB::table('tbl_factory_ninetydeg_laravel as ninetydeg')
            ->leftJoin('mstr_emp as emp1', 'ninetydeg.ninetydeg_operator', '=', 'emp1.id')
            ->leftJoin('mstr_emp as emp2', 'ninetydeg.ninetydeg_incharge', '=', 'emp2.id')
            ->leftJoin('hr_mstr_shift as sh', 'ninetydeg.ninetydeg_shift', '=', 'sh.id')
            ->select('ninetydeg.*', 'emp1.fullname as operator_name', 'emp2.fullname as incharge_name', 'sh.shift as shift_name')
            ->where('ninetydeg.ninetydeg_id', $id)
            ->first();
        $data['defectDetails'] = DB::table('tbl_factory_ninetydeg_defect_laravel as def')
            ->select('def.*', 'emp.fullname as responsible_person')
            ->leftJoin('mstr_emp as emp', 'def.res_prsn', '=', 'emp.id')
            ->where('def.ninetydeg_Id', $id)
            ->get();
        $data['laminatorHistory'] = DB::table('tbl_factory_ninetydeg_history_laravel as history')
            ->select('history.*', 'emp.fullname as created_by')
            ->leftJoin('mstr_emp as emp', 'history.created_by', '=', 'emp.id')
            ->where('history.ninetydeg_id', $id)
            ->get();
        $data['DmgRsn'] = DB::table('master_type_dtls')
            ->select('master_type_dtls.*')
            ->where('master_type_dtls.parent_id', 44)
            ->get();
        $data['DmgCat'] = DB::table('master_type_dtls')
            ->select('master_type_dtls.*')
            ->where('master_type_dtls.parent_id', 43)
            ->get();
        $data['DmgMachine'] = DB::table('master_type_dtls')
            ->select('master_type_dtls.*')
            ->where('master_type_dtls.parent_id', 47)
            ->get();
        $data['userList'] = DB::table('mstr_emp')
            ->select('mstr_emp.id', 'mstr_emp.fullname')
            ->where('mstr_emp.status', '1')
            ->get();
        $batchNo = $data['laminatorDetails']->ninetydeg_batchNo;
        $data['bushingMaterial'] = DB::table('tbl_factory_production_setup_laravel as psl')
            ->select('psl.cellRow', 'psl.celColumn')
            ->where('psl.batchNo', $batchNo)
            ->first();
            
        $data['PermittedMenuList'] = self::PermittedMenuList(request()->session()->get('empId'));
        return view('ProductionLineUp.NinetyDeg.view_90deg_qc', $data);
    }
    
    public function fetchRFIDBar(Request $request)
    {
        $batchNo = $request->input('batch_No');
        $elqcNo = $request->input('elqcNo');

        $RFIDBardtls = DB::table('tbl_factory_el_qc_laravel as bol')
            ->select('bol.elqc_rfid','bol.elqc_barcode')
            ->where('bol.elqc_batchNo', $batchNo)
            ->where('bol.elqc_id', $elqcNo)
            ->first();

        return response()->json(['rfid' => $RFIDBardtls->elqc_rfid, 'barcode' => $RFIDBardtls->elqc_barcode]);
    }
}
